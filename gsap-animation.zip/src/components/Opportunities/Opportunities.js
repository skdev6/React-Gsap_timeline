import React from 'react'

import image from '../../assets/opportunities.png'
import styles from './Opportunities.module.scss'

const Opportunities = ({ data }) => {
  const { document, content } = data

  return (
    <div className={styles.container}>
     <div style={{ height: "100vh"}}></div>
    Lorem ipsum dolor sit amet consectetur adipisicing elit. Eum expedita hic quaerat quisquam minus magnam est ad sed deleniti nesciunt.
    </div>
  )
}

export default Opportunities
