const breakpoints = {
	tablet: 1200,
	iPadPro: 1024,
	iPadVertical: 768,
	mobile: 767,
	iPhoneSE: 320
}

export default breakpoints
