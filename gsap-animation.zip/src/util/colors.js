export default {
	electricBlue: '#2251ff',
	deepBlue: '#ad259b',
	cyan: '#00a9f4',
	hoverBlue: '#0f2a76',
	grayLightest: '#F0F0F0',
	grayMedium: '#b3b3b3',
	grayDark: '#757575',
	black: '#000000',
	white: '#ffffff'
}
